# telegram-to-firebase (GitHub Pages + Bot)

This package contains a simple example to forward Telegram messages into Firebase Realtime Database and display them on a static GitHub Pages page.

IMPORTANT SECURITY NOTE
- **Do NOT commit your real bot token or Firebase secrets to a public GitHub repository.**
- Use environment variables or the hosting provider's secret manager.
- The included `bot.js` uses the token from `.env` (if present) but has a fallback with the token embedded for convenience. Remove that fallback before publishing!

## Files
- `index.html` -> Static page to upload to GitHub Pages. Edit `FIREBASE_DATABASE_URL` inside the file.
- `bot.js` -> Node script to run the Telegram bot and push messages to Firebase.
- `.env.example` -> Example env variables.
- `.gitignore` -> Ignore `node_modules` and `.env`.

## Quick start (local)
1. Copy this repo to your machine and `cd` into it.
2. Run `npm init -y && npm install node-telegram-bot-api axios dotenv`
3. Create `.env` from `.env.example` and set your TELEGRAM_TOKEN and FIREBASE_URL.
4. Start bot: `node bot.js`
5. Upload `index.html` to your GitHub repo and enable GitHub Pages (branch: main, folder: /).
6. Make sure Firebase Realtime Database rules allow `.read` for public page:
```
{
  "rules": {
    ".read": true,
    ".write": false
  }
}
```

## Deployment suggestions
- Use Render.com, RailWay, or Replit to run `bot.js` 24/7.
- On hosting platforms, set TELEGRAM_TOKEN and FIREBASE_URL as environment variables instead of committing `.env`.

## Replacing placeholders
- Inside `index.html` replace `https://your-project-id.firebaseio.com` with your DB URL (no trailing slash).
- In `.env` set `FIREBASE_URL` ending with `/messages.json` (example: `https://project-id.firebaseio.com/messages.json`).

